using System;
using Server;

namespace Server.Items
{
	public class BlackthornsKryss : Kryss
	{
		public override int LabelNumber{ get{ return 1073260; } } // Blackthorn's Kryss - Museum of Vesper Replica	

		public override int InitMinHits{ get{ return 80; } }
		public override int InitMaxHits{ get{ return 80; } }

		[Constructable]
		public BlackthornsKryss() : base()
		{
			Hue = 0x5E5;
			
			Slayer = SlayerGroup.Groups[ Utility.Random( SlayerGroup.Groups.Length ) ].Super.Name;
			
			Attributes.WeaponSpeed = 25;
			Attributes.WeaponDamage = 50;
			
			WeaponAttributes.UseBestSkill = 1;
			WeaponAttributes.HitLeechHits = 22;
		}

		public BlackthornsKryss( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}
	
	public class SwordOfJustice : VikingSword
	{
		public override int LabelNumber{ get{ return 1073261; } } // Sword of Justice - Museum of Vesper Replica

		public override int InitMinHits{ get{ return 80; } }
		public override int InitMaxHits{ get{ return 80; } }

		[Constructable]
		public SwordOfJustice() : base()
		{
			Hue = 0x47E;
			
			Slayer = SlayerGroup.Groups[ Utility.Random( SlayerGroup.Groups.Length ) ].Super.Name;
			
			Attributes.SpellChanneling = 1;
			Attributes.CastSpeed = -1;
			Attributes.WeaponDamage = 50;
			Attributes.Luck = 100;
			
			WeaponAttributes.UseBestSkill = 1;
			WeaponAttributes.HitLowerAttack = 60;
		}

		public SwordOfJustice( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}
	
	public class GeoffreysAxe : ExecutionersAxe
	{
		public override int LabelNumber{ get{ return 1073263; } } // Geoffrey's Axe - Museum of Vesper Replica

		public override int InitMinHits{ get{ return 80; } }
		public override int InitMaxHits{ get{ return 80; } }

		[Constructable]
		public GeoffreysAxe() : base()
		{
			Hue = 0x21;
			
			Slayer = SlayerGroup.Groups[ Utility.Random( SlayerGroup.Groups.Length ) ].Super.Name;
			
			Attributes.BonusStr = 10;
			Attributes.AttackChance = 15;
			Attributes.WeaponDamage = 40;
			Attributes.Luck = 150;
			
			WeaponAttributes.ResistFireBonus = 10;			
			WeaponAttributes.UseBestSkill = 1;
			WeaponAttributes.HitLowerAttack = 60;
		}

		public GeoffreysAxe( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}
}

