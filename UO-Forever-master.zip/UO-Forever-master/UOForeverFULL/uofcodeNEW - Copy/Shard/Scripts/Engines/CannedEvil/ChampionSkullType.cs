// **********
// RunUO Shard - ChampionSkullType.cs
// **********

namespace Server.Engines.CannedEvil
{
    public enum ChampionSkullType
    {
        Power,
        Enlightenment,
        Venom,
        Pain,
        Greed,
        Death,
        Special,
		Aspect
    }
}