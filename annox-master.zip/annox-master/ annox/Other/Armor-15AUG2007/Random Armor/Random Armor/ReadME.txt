Random Blade With Armor And Jewls

Here is the package of random blades from EternaL2K which you may
go online to download at
 http://www.runuo.com/forum/showthread.php?t=51572

This package includes of course random armor, jewls and blade.

All of this items will include random attributes in each one of them,
you may change the attributes to what ever you want.

If you need more help come visit my forums and post your problem there,
we will be glad to help you or you may also post on the thread for this
package.
Darkness_PR
DxM Website & Forums:
http://www.freewebs.com/deathxmurder/index.htm
