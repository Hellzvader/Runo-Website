Greetings,

Remember when you first started playing UO, if your a really old timer, you did not know if you were talking to a NPC or a real person.  Now you can wonder again.

Description:
Creates a NPC that creates random sentences from a XML file.  It will automatically talk to the player when he/she comes with in 3 titles.

Installation:
Drop it in your Custom folder.
Save the StoryTellerList.xml to your /DATA folder
Restart the server.

Credits:
sordican's - I used some of his "Chuck Norris" script for the timer.
Michael Andrew Harver - for conecpt idea from his 1996 program called Agen.
RavonTUS - XML code and other improvements.

Play at An Nox, the cure for the UO addiction.
http://annox.no-ip.com
