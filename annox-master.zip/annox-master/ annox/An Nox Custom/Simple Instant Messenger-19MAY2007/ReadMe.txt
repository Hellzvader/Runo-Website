Greetings,

There are some good chat & mail programs out there for RunUO, however, I wanted something simple.  I wanted to know who was online and I wanted to send them an instant message.  Thus, Simple Instant Messenger (SIM).  Type in the command [SIM or [IM and pick a player from the list.  Send them a message and poof a message pops up on their screen.

Description:
Allows players to send message to other players on line.

Installation:
Drop it in your Custom folder.
Restart the server.
[SIM or [IM or [CHAT or [C

NOTE: If you are using someone else's chat system remove line 16 & 17 from SIMGumpList.cs

Credits:
RunUO Devs - I used the WHOGUMP.CS for the base of this script.
RavonTUS - code modifications, gump, conecpt and other improvements.

RunUO v2 SVN182

-Ravon