using System;
using Server;

namespace Server.Items
{
	public class Coral : BaseFish
	{		
		public override int LabelNumber{ get{ return 1074588; } } // Coral
		
		[Constructable]
		public Coral() : base( Utility.RandomList( 0x3AF9, 0x3AFA, 0x3AFB ) )
		{
		}
		
		public Coral( Serial serial ) : base( serial )
		{		
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}
}