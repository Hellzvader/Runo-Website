using System;

namespace Server.Items
{
	public class StaffTub : DyeTub, Engines.VeteranRewards.IRewardItem
	{
		public override bool AllowDyables{ get{ return false; } }
		public override bool AllowLeather{ get{ return true; } }
		public override int TargetMessage{ get{ return 1042416; } } // Select the leather item to dye.
		public override int FailMessage{ get{ return 1042418; } } // You can only dye leather with this tub.
		public override int LabelNumber{ get{ return 1041284; } } // Leather Dye Tub
		public override CustomHuePicker CustomHuePicker{ get{ return CustomHuePicker.StaffTub; } }

		private bool m_IsRewardItem;

		[CommandProperty( AccessLevel.GameMaster )]
		public bool IsRewardItem
		{
			get{ return m_IsRewardItem; }
			set{ m_IsRewardItem = value; }
		}

		[Constructable]
		public StaffTub()
		{
			LootType = LootType.Blessed;
			Name = "StaffTub";
			Weight = 500;

		}

		public override void OnDoubleClick( Mobile from )
		{
			if ( m_IsRewardItem && !Engines.VeteranRewards.RewardSystem.CheckIsUsableBy( from, this, null ) )
				return;

			base.OnDoubleClick( from );
		}

		public StaffTub( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 1 ); // version

			writer.Write( (bool) m_IsRewardItem );
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();

			switch ( version )
			{
				case 1:
				{
					m_IsRewardItem = reader.ReadBool();
					break;
				}
			}
		}
	}
}