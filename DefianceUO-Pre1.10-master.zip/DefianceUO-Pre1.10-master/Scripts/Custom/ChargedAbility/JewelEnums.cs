using System;

namespace Server.Items
{
    public enum JewelChargedAbility
    {
        Regular,
        Cunning,
        Strength,
        Agility,
        Bless,
        Invisibility,
        Teleport,
    }
}